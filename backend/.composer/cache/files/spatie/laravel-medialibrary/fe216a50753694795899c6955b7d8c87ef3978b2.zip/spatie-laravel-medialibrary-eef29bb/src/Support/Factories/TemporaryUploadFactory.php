<?php

namespace Spatie\MediaLibrary\Support\Factories;

class TemporaryUploadFactory {}
